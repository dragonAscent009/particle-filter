#!/usr/bin/env python
from turtlebot_ctrl.srv import TurtleBotControl
from std_msgs.msg import Bool, Float32
import rospy
import numpy as np
import pickle as pkl
import os
import re
from math import radians, cos, sin, sqrt, isnan, degrees
from shapely.geometry import Polygon, LineString, LinearRing
import numpy as np
import matplotlib.pyplot as plt
import pickle as pkl
import scipy.stats
import rospy
from gazebo_msgs.srv import SetModelState, GetModelState
from gazebo_msgs.msg import ModelState
from random import uniform

def get_coords_from_string(s):
    s_list = s.rstrip().split(" ")
    coords = [list(map(float, re.findall("[+-]?\d+(?:\.\d+)?",x))) for x in s_list]
    return coords


# In[51]:


def get_map_deets_from_file(filename):
    base_path = "/home/shogo/catkin_ws/src/comprobfall2018-hw3-master/turtlebot_maps"
    path_to_file = os.path.join(base_path, filename)
    fd = open(path_to_file , 'r')
    count = 0
    map_bounds = []
    obstacle_bounds = []
    for line in fd:
        if count == 0:
            map_bounds = get_coords_from_string(line)
        elif count > 1:
            obstacle_bounds.append(get_coords_from_string(line))
        count += 1
    return map_bounds, obstacle_bounds


# In[52]:


class Point:
    def __init__(self,**kwargs):
        if kwargs.get('point', None):
            point = kwargs.get('point')
            self.x = point[0]
            self.y = point[1]
        else:
            self.x = kwargs.get('x',None)
            self.y = kwargs.get('y',None)
    def get_coords(self):
        return [self.x, self.y]
#fixed the multilinestring issue
class ScanData:
    def __init__(self, map_bounds,polygon_bounds):
		self.angle_range = [-30,30]
		self.angle_delta = 1.125
		self.max_dist = 5.5
		self.min_dist = 0.45
		self.polygons = [Polygon(poly) for poly in polygon_bounds]
		self.walls = LinearRing(map_bounds)
    @staticmethod
    def get_point_at_an_angle(point, d, theta):
        theta_rad = radians(theta)
        return Point(x = point.x + d*cos(theta_rad), y = point.y + d*sin(theta_rad)).get_coords()
    def get_intersection_points(self, point, rad):
        min_angle = self.angle_range[0]
        max_angle = self.angle_range[1]
        angles = np.arange(min_angle,max_angle,self.angle_delta) + rad
        line_segments = [LineString([point.get_coords(), self.get_point_at_an_angle(point,self.max_dist,angle)]) for angle in angles]
        points = []
        locations = []
        for l_s in line_segments:
            i_points = []
            for poly in self.polygons:
                if l_s.intersects(poly):
                    inter = l_s.intersection(poly)
                    i_poins = None
                    if inter.geom_type == "LineString":
                        i_point = list(l_s.intersection(poly).coords)[0]
                    elif inter.geom_type == "MultiLineString":
                        i_point = inter[0].coords[0]
                    i_points.append(Point(point=i_point))
                if l_s.intersects(self.walls):
                    wall_inter = l_s.intersection(self.walls)
                    if wall_inter.geom_type == "Point":
                        i_points.append(Point(point=list(list(l_s.intersection(self.walls).coords)[0])))
                    else:
                        print(point.get_coords())
                        print(wall_inter.geom_type)
                        print(wall_inter)
                if len(i_points) != 0:
                    best = i_points[0]
                    min = self.euclidean_distance(best,point)
                    for i_p in i_points:
                        dist = self.euclidean_distance(point,i_p)
                        if dist < min:
                            best = i_p
                            min = dist
				# considering the turlte bots radius
                    points.append(min - 0.175)
                    locations.append(best)
                else:
                    points.append(100)
        #self.plotter_function(self.polygons, locations, point)
        return points
    @staticmethod
    def plotter_function(polygons, points, point):
        plt.figure(figsize=(10,10))
        for i in polygons:
            x,y = i.exterior.xy
            plt.plot(x, y, color='#6699cc', alpha=0.7,
            linewidth=3, solid_capstyle='round', zorder=2)
        data = [p.get_coords() for p in points]
        if len(data) != 0:
            plt.scatter(*zip(*data))
            for i in data:
                plt.plot([point.x,i[0]],[point.y,i[1]],'ro-')
            plt.show()
    @staticmethod
    def euclidean_distance(p,q):
        return sqrt((p.x-q.x)**2 + (p.y-q.y)**2)


# In[16]:


##TESTING PURPOSES CODE
#fetching  details of first map
#issue with a small space in the text file in map_3 rest all maps are working Fine
# map_bounds, obstacle_bounds = get_map_deets_from_file("map_4.txt")
# print(len(obstacle_bounds))
# scan = ScanData(obstacle_bounds)
# data = scan.get_intersection_points(Point(x=6,y=-8.5),90)
# print(data)
# print(len(data))
class TrajectoryData:
	def __init__(self,heading, distance, ground_truth, noisy_heading, noisy_distance, scan_data):
		self.heading = heading
		self.distance = distance
		self.ground_truth = ground_truth
		self.noisy_heading = noisy_heading
		self.noisy_distance = noisy_distance
		self.scan_data = scan_data
class GroundTruthData:
	def __init__(self,model_name, pose, twist, reference_frame):
		self.model_name = model_name
		self.pose = pose
		self.twist = twist
		self.reference_frame = reference_frame
class Pose:
	def __init__(self,position,orientation):
		self.position = position
		self.orientation = orientation
class Twist:
	def __init__(self,linear,angular):
		self.linear = linear
		self.angular = angular
class Coordinate:
	def __init__(self, x,y,z):
		self.x = x
		self.y = y
		self.z = z

class Particle:
    def __init__(self, point, heading, weight=0):
        self.loc = Point(point=point)
        self.heading = heading
        self.weight = weight

class ParticleFilter:
    def __init__(self,particle_count, particles, initial_location, initial_heading, map_name):

		self.particle_count = particle_count
		self.particles = particles
		self.trans_sd = rospy.get_param("/translation_noise")
		self.rot_sd = rospy.get_param("/rotation_noise")
		self.las_sd = rospy.get_param("/scan_noise")
		# self.trans_sd = rospy.get_param("/translation_noise")
		# self.rot_sd = rospy.get_param("/rotation_noise")
		# self.las_sd = rospy.get_param("/scan_noise")
		map_bounds, polygon_bounds = get_map_deets_from_file(map_name)
		self.polygons = [Polygon(poly) for poly in polygon_bounds]
		self.scanner = ScanData( map_bounds, polygon_bounds)
		self.map_bounds = map_bounds
    def generate_new_particles(self, scan_data, observed_location, heading = None, trans = None):
        print(self.particles)
        new_particles = []
        if len(self.particles) == 1:
            p = self.particles[0]
#             print("number of particles is 1")
            if (trans != 0.0):
                sampled_translations = np.random.normal(trans, self.trans_sd,self.particle_count)
                loc = p.loc.get_coords()
                new_particles =  [Particle([loc[0] + d*cos(radians(p.heading)),loc[1] + d*sin(radians(p.heading))], p.heading) for d in sampled_translations]
            elif (heading):
                heading_in_degrees = degrees(heading)
                sampled_rotations = np.random.normal(heading_in_degrees, self.rot_sd,self.particle_count)
                new_particles = [Particle(p.loc.get_coords(),r) for r in sampled_rotations]
        else:
#             print("before", len(self.particles))
#             print(trans,heading)
            heading=degrees(heading)
            for particle in self.particles:
                if (trans != 0.0):
#                     print("entered")
                    sampled_trans = np.random.normal(trans, self.trans_sd)
                    loc = particle.loc.get_coords()
                    new_particles.append(Particle([loc[0] + sampled_trans*cos(radians(particle.heading)), loc[1] + sampled_trans*sin(radians(particle.heading))], particle.heading))
                else:
#                     print("heading")
                    sampled_rot = np.random.normal(heading, self.rot_sd)
                    new_particles.append(Particle(particle.loc.get_coords(), sampled_rot))
        print("particles count", len(new_particles))

        weighted_particles = self.weight_samples(new_particles, scan_data)
        print(len(weighted_particles))
        new_particles = self.resample(weighted_particles, self.particle_count)
        self.plot_function(self.polygons, self.map_bounds, new_particles,  observed_location)
        self.particles = new_particles
    @staticmethod
    def plot_function(polygons, map_bounds, particles, observed_location):
        print("plotter called")
        plt.figure(figsize=(10,10))
        walls = LinearRing(map_bounds)
        a,b = walls.xy
        plt.plot(a, b, color='#6699cc', alpha=0.7, linewidth=1, solid_capstyle='round', zorder=2)
        for i in polygons:
            x,y = i.exterior.xy
            plt.plot(x, y, color='#6699cc', alpha=0.7,
            linewidth=3, solid_capstyle='round', zorder=2)
        plt.plot([observed_location[0]],[observed_location[1]],'ro')
        data = [p.loc.get_coords() for p in particles]
        plt.scatter(*zip(*data))
        plt.show()
    @staticmethod
    def resample(particles, particle_count):
        probabilities = [ x.weight for x in particles]
	#         print(probabilities)
        new_particles = np.random.choice(particles, particle_count, p=probabilities)
        return new_particles
    @staticmethod
    def withinWalls(point, map_bounds):
        loc = point.loc
        mapLocs = sorted(map_bounds, key = lambda x: [x[0],x[1]])
        x_start, y_start, x_end, y_end = mapLocs[0][0],mapLocs[0][1],mapLocs[-1][0],mapLocs[-1][1]
        return not (loc.x > x_end or loc.x < x_start or loc.y > y_end or loc.y < y_start)
    def weight_samples(self,locations,observed_scan_data):
        new_particles = []
        weight_sum = 0
        for loc in locations:
            if not self.withinWalls(loc, self.map_bounds):
                continue
            a_s = self.scanner.get_intersection_points(loc.loc,loc.heading)
            if not self.is_colliding(a_s):
                weight = self.get_probability(a_s,observed_scan_data)
                new_particles.append(Particle(loc.loc.get_coords(),loc.heading,weight))
                weight_sum += weight
#         print("weigh sum",weight_sum)
        for p in new_particles:
            p.weight = p.weight/weight_sum
        return new_particles
    @staticmethod
    def is_colliding(a):
        return sum(a) == 0
    def get_probability(self,a,o):
        o_s = []
        for i in o:
            o_s.append(100 if isnan(i) else i)
        p = 0
        for i in range(len(o_s)):
            prob = scipy.stats.norm(o_s[i],self.las_sd).pdf(a[i])
            p += prob
#         print("probability",p)
        return p


class TurtlebotControlClient:
    def __init__(self):
        rospy.init_node("turtlebot_control_client")

        rospy.wait_for_service("turtlebot_control")
        self.turtlebot_control_service = rospy.ServiceProxy("turtlebot_control",TurtleBotControl)
    @staticmethod
    def parse_output(output):
        ground_truth = output.ground_truth
        position = ground_truth.pose.position
        orientation = ground_truth.pose.orientation
        linear = ground_truth.twist.linear
        angular = ground_truth.twist.angular
        p_coords = Coordinate(position.x, position.y, position.z)
        o_coords = Coordinate(orientation.x, orientation.y, orientation.z)
        l_coords = Coordinate(linear.x, linear.y, linear.z)
        a_coords = Coordinate(angular.x, angular.y, angular.z)
        return GroundTruthData(ground_truth.model_name,Pose(p_coords,o_coords),Twist(l_coords,a_coords), ground_truth.reference_frame), output.noisy_heading, output.noisy_distance, output.scan_data.ranges

    def run(self):
		#f_r = open("trajectories.txt", "w+")

        key = ""
        heading = Float32()
        heading.data = 0.0
        distance = Float32()
        return_ground_truth = Bool()
        return_ground_truth.data = True
        count = 500

		#initial_location = [-6,7]
		#initial_location=model_state.pose
        initial_location=[rospy.get_param("/initial_location_x"),rospy.get_param("/initial_location_y")]
        initial_heading = 0
		# file = open("trajectory_w4_-6,7.pkl","rb")
		# data = pkl.load(file)
		# file.close()
        map_name = "map_{}.txt".format(rospy.get_param("/map"))
        map_bounds, polygon_bounds = get_map_deets_from_file(map_name)

        def generate_random_particles(count, map_bounds):
            particles = []
            mapLocs = sorted(map_bounds, key = lambda x: [x[0],x[1]])
            x_start, y_start, x_end, y_end = mapLocs[0][0], mapLocs[0][1], mapLocs[-1][0], mapLocs[-1][1]
            for i in range(count):
                x = uniform(x_start, x_end)
                y = uniform(y_start, y_end)
                theta = 0
                particles.append(Particle([x,y], theta, 0))
            return particles
        particles=generate_random_particles(count, map_bounds)
        p = ParticleFilter(count, particles, initial_location , initial_heading, map_name)


        while key != 's':
            key = raw_input("PRESS CONTROL KEYS:\n(The rotation keys rotate the turtlebot with respect to x-axis)\nl : +45 degree\na : -45 degree\nt : +90 degree\nv : -90 degree\nj : 0 degree\nf : -180 degree\nh : +135 degree\ng: -135 degree\n\nd : to move 1 cm\nm : to move sqrt(2) cm (diagonally)\n\ns : to stop\n")
            distance.data = 0.0

			# current_data = []
			# if os.path.isfile('trajectory.pkl'):
			# 	print("file exists")
			# 	p_r = open('trajectory.pkl','rb')
			# 	current_data = pkl.load(p_r)
			# 	print(current_data)
			# 	print("****************************************************************")
			# 	p_r.close()

            if key == 'l':
			             heading.data = np.pi/4
            elif key == 'a':
			             heading.data = -np.pi/4
            elif key == 't':
			             heading.data = np.pi/2
            elif key == 'v':
			             heading.data = -np.pi/2
            elif key == 'j':
                heading.data = 0
            elif key == 'f':
                heading.data = -np.pi
            elif key == 'h':
                heading.data = 3*np.pi/4
            elif key == 'g':
                heading.data = -3*np.pi/4
            elif key == 'd':
                distance.data = 1.0
            elif key == 'm':
                distance.data = 1.414
			#
			#print("Heading: "+str(heading))
			# print("Distance: "+str(distance))
			# f_r.write("Heading: "+str(heading)+"\n")
			# f_r.write("Distance: "+str(distance)+"\n")
            output = self.turtlebot_control_service(heading, distance, return_ground_truth)
			# # print(output)
			# f_r.write(str(output)+"\n")
            ground_truth_data, noisy_heading, noisy_distance, scan_data = self.parse_output(output)
            print("--------------------------------------")
			#print(noisy_distance, noisy_heading, scan_data)
			#p_w = open("trajectory.pkl","wb")
            data = TrajectoryData(float(heading.data), float(distance.data), ground_truth_data, float(noisy_heading.data), float(noisy_distance.data), list(map(float, scan_data)))
			#current_data.append(trajectory_data)
			#print(current_data)
			#pkl.dump(current_data, p_w)
			#p_w.close()

            position = data.ground_truth.pose.position
            p.generate_new_particles(data.scan_data, [position.x,position.y] ,data.heading, data.distance)

		#f_r.close()
        rospy.spin()

if __name__ == "__main__":
	try:
		turtlebot_control_client = TurtlebotControlClient()
		turtlebot_control_client.run()
	except rospy.ROSInterruptException:
		pass
