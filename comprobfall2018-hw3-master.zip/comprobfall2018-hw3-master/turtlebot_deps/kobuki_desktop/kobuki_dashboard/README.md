Kobuki Dashboard
====================

This is a dashboard for [Kobuki](http://kobuki.yujinrobot.com/).

It is based on the [rqt_robot_dashboard](https://github.com/ros-visualization/rqt_robot_plugins) framework and runs in [rqt](https://github.com/ros-visualization/rqt).
You can run this dashboard by calling:

`rosrun kobuki_dashboard kobuki_dashboard`

or through rqt:

`rqt -s kobuki_dashboard`

