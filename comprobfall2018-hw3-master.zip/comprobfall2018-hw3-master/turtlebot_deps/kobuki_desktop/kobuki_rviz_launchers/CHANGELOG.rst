^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package kobuki_rviz_launchers
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.4.2 (2015-03-02)
------------------

0.4.1 (2014-09-19)
------------------

0.4.0 (2014-08-11)
------------------
* removes email addresses from authors
* adds package for rviz launchers
* Contributors: Marcus Liebhardt

0.3.3 (2014-08-05)
------------------
* update changelog
* Contributors: Jihoon Lee

0.3.2 (2014-04-23)
------------------
* update changelog
* update package version
* removes email addresses from authors
* adds package for rviz launchers
* Contributors: Jihoon Lee, Marcus Liebhardt

0.3.1 (2013-10-14)
------------------

0.3.0 (2013-09-11)
------------------

0.2.0 (2013-08-09)
------------------

0.1.7 (2013-07-11)
------------------

0.1.6 (2013-04-16)
------------------

0.1.5 (2013-02-16)
------------------

0.1.3 (2013-02-05)
------------------

0.1.2 (2012-12-24)
------------------

0.1.1 (2012-12-22 21:20)
------------------------

0.1.0 (2012-12-22 04:28)
------------------------
