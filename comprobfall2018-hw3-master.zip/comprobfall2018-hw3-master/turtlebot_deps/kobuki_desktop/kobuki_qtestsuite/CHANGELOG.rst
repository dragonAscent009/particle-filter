^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package kobuki_dashboard
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.5.7 (2017-05-14)
------------------
* bugfix for pyqt4->pyqt5 pyrrc tools rosdep

0.5.4 (2017-03-28)
------------------
* refactoring for pyqt5 QtGui -> QWidget
* workaround for the multi matplotlib crash bug

0.4.0 (2014-08-11)
------------------
* now it uses Rqt DataPlot instead our own version
* uses dataplot
* now it uses dataplot class instead of mat dataplot. It still shows weird scaling though..
* removes email addresses from authors
* add robot groups for rqt plugins
* Contributors: Dirk Thomas, Jihoon Lee, Marcus Liebhardt

0.3.1 (2013-10-14)
------------------

0.3.0 (2013-08-30)
------------------
* adds bugtracker and repo info to package.xml
* bugfix new matdataplot api with resizing the plot

0.2.0 (2013-07-11)
------------------
* ROS Hydro beta release.
* Adds catkinized kobuki_qtestsuite

